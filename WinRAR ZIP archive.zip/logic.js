ExecuteTests()
function sequenceFizzBuzz(start, step) {
    if (!check2(start) || !check2(step)) {
        return null;
    }
    if (step == 0) step = 1;
    start = parseInt(start);
    step = parseInt(step);
    if (check(start) && check(step))
        var a = function() {
            var out = "";
            if (9007199254740990 <= start) {
                alert("This is a completely different story")
                return null;
            }
            if (start == 0) {
                start += step;
                return 0;
            }
            if (start % 3 == 0 && start % 5 == 0) {
                out = "FizzBuzz";
            } else if (start % 3 == 0) {
                out = "Fizz";
            } else if (start % 5 == 0) {
                out = "Buzz";
            } else {
                out = start;
            }
            start += step;
            return out;
        }
    else {
        return null;
    }

    return a;
}

function ExecuteTests() {
    TestPack1();
}

function TestPack1() {
    Test__p1_0__p2_0();
    Test__p1_0__p2_1();
    Test__p1_3__p2_4();
    Test__p1_0__p2_1__6times()
    Test__p1_3__p2_2__7times()
    Test__p1_3__p2_4__2times();
    Test__p1_3__p2_4__201times();
    Test__p1_String__p2_String2();
    Test__p1_quotes__p2_quotes();
    Test__p1_null__p2_null()
    Test__p1_Infinity__p2_Infinity()
    Test__p1_func__p2_func()
    Test__mas_func__pmas_func()
}

function Test__p1_0__p2_0() {
    TestTemplate(0, 0, 0, 1);
}

function Test__p1_0__p2_1() {
    TestTemplate(0, 1, 0, 1);
}

function Test__p1_3__p2_4() {
    TestTemplate(3, 4, "Fizz", 1);
}

function Test__p1_0__p2_1__6times() {
    TestTemplate(0, 1, "Buzz", 6);
}

function Test__p1_3__p2_2__7times() {
    TestTemplate(3, 2, "FizzBuzz", 7);
}

function Test__p1_3__p2_4__2times() {
    TestTemplate(3, 4, 7, 2);
}

function Test__p1_3__p2_4__201times() {
    TestTemplate(3, 4, 803, 201);
}

function Test__p1_String__p2_String2() {
    TestTemplate("String", "String2", null, 1);
}

function Test__p1_quotes__p2_quotes() {
    TestTemplate("", "", null, 1);
}

function Test__p1_null__p2_null() {
    TestTemplate(null, null, null, 1);
}

function Test__p1_Infinity__p2_Infinity() {
    TestTemplate(Infinity, Infinity, null, 1);
}

function Test__p1_func__p2_func() {
    var a = function test1() {

    }
    var b = function test2() {

    }
    TestTemplate(a, b, null, 1);
}
function Test__mas_func__pmas_func() {
    var a = [1,2];
    var b = [3,4];
    TestTemplate(a, b, null, 1);
}




function TestTemplate(p1, p2, res, count) {
    try {
        var testFunc = sequenceFizzBuzz(p1, p2);
        if (testFunc == null && res == null) {
            if (typeof p1 == "function") p1 = "tempFunction1";
            if (typeof p2 == "function") p2 = "tempFunction2";

            if (typeof p1 == "object") p1 = "tempObject1";
            if (typeof p2 == "object") p2 = "tempObject2";

            
            console.log("Тест(Test__p1_" + p1 + "__p2_" + p2 + "__" + count + "times). Результат ОК")
            return;
        } else if (testFunc == null && res != null) {
            console.log("Тест(Test__p1_" + p1 + "__p2_" + p2 + "__" + count + "times). Результат ОШБИКА")
            return;
        }
        for (let i = 1; i < count; i++) {
            testFunc();
        }
        if (testFunc() == res)
            console.log("Тест(Test__p1_" + p1 + "__p2_" + p2 + "__" + count + "times). Результат ОК")
        else
            console.log("Тест(Test__p1_" + p1 + "__p2_" + p2 + "__" + count + "times). Результат ОШБИКА")
    } catch (e) {
        console.log("Тест(Test__p1_" + p1 + "__p2_" + p2 + "__" + count + "times). Результат ОШБИКА")

    }

}
function check2(value) {
    if (/[^[0-9]/.test(value)) {
        return false;
    } else {
        return true;
    };
}
function check(value) {
    return (value instanceof Number || typeof value === 'number') && !isNaN(value);
}